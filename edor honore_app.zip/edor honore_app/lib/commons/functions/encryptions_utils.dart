import 'dart:io';

import "package:encryption_lib/encryption_lib.dart";

File encryptFileWithLib(File file) {
  return encryptFile(file);
}
