import 'package:flutter/cupertino.dart';

const cupertinoLightTheme = CupertinoThemeData(
  applyThemeToAll: false,
);
