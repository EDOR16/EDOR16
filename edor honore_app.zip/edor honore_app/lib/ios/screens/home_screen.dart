import 'package:connect_app/commons/layouts/rounded_top_app_bar_layout.dart';
import 'package:flutter/widgets.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return RoundedTopAppBarLayout(
      body: Container(),
    );
  }
}
